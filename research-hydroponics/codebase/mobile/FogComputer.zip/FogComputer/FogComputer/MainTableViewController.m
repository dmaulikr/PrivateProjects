//
//  MainTableViewController.m
//  FogComputer
//
//  Created by Parth Kalavadia on 3/16/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import "MainTableViewController.h"
#import "HydroponicsSystem.h"
#import "AppDelegate.h"
#import "DetailViewController.h"
#import "Constant.h"
@interface MainTableViewController ()
@property (strong,nonatomic)NSMutableArray* dataSource;
@end

@implementation MainTableViewController
@synthesize dataSource;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
   // [self.navigationItem setHidesBackButton:YES animated:YES];

    [self loadHydroponicsSystems];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadHydroponicsSystems) name: NOTIFICATION_SENSORDATA_UPDATED object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateArried) name: NOTIFICATION_USER_UPDATED object:nil];
    
}

-(void)updateArried
{
    UIAlertController*alertcontroller = [UIAlertController alertControllerWithTitle:@"Message" message:@"New plantes details updated" preferredStyle:UIAlertControllerStyleAlert];
    
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {

                                                              }];
    [alertcontroller addAction:defaultAction];
    
         [self presentViewController:alertcontroller animated:YES completion:nil];
    
    [self loadHydroponicsSystems];
}

-(void)loadHydroponicsSystems
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSManagedObjectContext *context = appDelegate.managedObjectContext;
    dataSource = [NSMutableArray arrayWithArray:[HydroponicsSystem getAllHydroponicSystems:context]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Table view data source

//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Incomplete implementation, return the number of sections
//    return 0;
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [dataSource count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"hydroponicCell" forIndexPath:indexPath];
    
    HydroponicsSystem* hSystem = [dataSource objectAtIndex:indexPath.row];
    
    UILabel* hydroponicsSystemlbl = (UILabel*)[cell.contentView viewWithTag:100];
    UILabel* arduinoIdLbl = (UILabel*)[cell.contentView viewWithTag:101];
    UILabel* emailIdLbl = (UILabel*)[cell.contentView viewWithTag:102];
    
    arduinoIdLbl.text = hSystem.deviceId;
    
    hydroponicsSystemlbl.text = (hSystem.plantId==nil)?@"Unassigned Hydroponic System":hSystem.plantId;
    
    emailIdLbl.text = (hSystem.plantId==nil)?@"":hSystem.userId;

    // Configure the cell...
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([[segue identifier] isEqualToString:@"DetailVCSegue"])
    {
        DetailViewController* DetailVC = [segue destinationViewController];
        NSIndexPath* x =[self.tableView indexPathForSelectedRow];
        NSLog(@"%ld",(long)x.row);
        
        NSInteger y= x.row;
        DetailVC.hSystem = [dataSource objectAtIndex:y];
        
        NSLog(@"%ld",(long)x.row);

    }
    
    
    
}


@end
