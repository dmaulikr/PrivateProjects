//
//  DetailViewController.m
//  FogComputer
//
//  Created by Parth Kalavadia on 3/17/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import "DetailViewController.h"
#import "ControlParameters.h"
#import "Constant.h"
@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UILabel *moistureLbl;
@property (weak, nonatomic) IBOutlet UILabel *phLbl;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *pHIndicator;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *moistureIndicator;
@property (weak, nonatomic) IBOutlet UILabel *parameterLbl;

@property (weak, nonatomic) IBOutlet UIImageView *lightIV;
@property (weak, nonatomic) IBOutlet UILabel *tdsLbl;

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *tdsIndicator;
@property (weak, nonatomic) IBOutlet UILabel *lightLbl;
@end

@implementation DetailViewController
@synthesize hSystem;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self loadSystemParameter];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadSystemParameter) name: NOTIFICATION_ACTUATOR_UPDATED object:nil];
    
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadSystemParameter
{
  //  NSLog(@"%@", boolValue ? @"YES" : @"NO");

    if (hSystem.param!=nil) {
        _parameterLbl.text = @"Parameter";
        if (!hSystem.param.isExternalLightOff) {
            _lightIV.image = [UIImage imageNamed:@"lightOn"];
        }else
            _lightIV.image = [UIImage imageNamed:@"lightOff"];

        if (hSystem.param.isMoistureBalance) {
            _moistureLbl.text = @"Moisture level Balanced";
            [_moistureIndicator stopAnimating];
            
        }else
        {
            _moistureLbl.text = @"Moisture level Balancing";
            [_moistureIndicator startAnimating];
        }
        
        if (hSystem.param.isPHBalance) {
            _phLbl.text = @"PH level Balanced";
            [_pHIndicator stopAnimating];
        }else{
            _phLbl.text = @"PH level Balancing";
            [_pHIndicator startAnimating];
        }
        
        if (hSystem.param.isTdsBalance) {
            _tdsLbl.text = @"Nutricient level Balanced";
            [_tdsIndicator stopAnimating];
        }else{
            _tdsLbl.text = @"Nutricient level Balancing";
            [_tdsIndicator startAnimating];
           
        }
    }else{
        _parameterLbl.text = @"System not setup yet";
    }
        

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
