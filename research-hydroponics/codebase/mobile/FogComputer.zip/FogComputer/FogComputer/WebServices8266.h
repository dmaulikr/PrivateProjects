//
//  WebServices8266.h
//  FogComputer
//
//  Created by Parth Kalavadia on 2/29/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HTTPResponseHandler.h"

@interface WebServices8266 : HTTPResponseHandler

@end
