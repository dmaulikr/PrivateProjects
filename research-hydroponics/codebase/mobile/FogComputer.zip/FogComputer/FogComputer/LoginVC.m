//
//  LoginVC.m
//  FogComputer
//
//  Created by Parth Kalavadia on 3/1/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import "LoginVC.h"
#import <AFNetworking/AFNetworking.h>
#import "INDWebservices.h"
#import "HydroponicsSystem+CoreDataProperties.h"
#import "ControlParameters.h"
#import "Constant.h"
#import "AppDelegate.h"
@interface LoginVC ()<webServiceResponceProtocol>
@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loginLoader;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@end

@implementation LoginVC
@synthesize userNameTF;
@synthesize passwordTF;
@synthesize loginBtn;
@synthesize loginLoader;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    userNameTF.text=@"krishna@scu.edu"; 
    passwordTF.text=@"bala";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    

}

- (IBAction)loginBtn:(UIButton *)sender {
    [self loginWithUsername:userNameTF.text andPassword:passwordTF.text];
}

-(void)loginWithUsername:(NSString*)username andPassword:(NSString*)password
{
    [loginLoader startAnimating];
    [loginBtn setEnabled:NO];
    NSURL* loginUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@login",SERVER_URL]];
    INDWebServiceModel* loginWebCall = [[INDWebServiceModel alloc] initWithDelegate:self url:loginUrl NameOfWebService:Login];
    NSDictionary* post=@{@"email":username,@"password":password};
    [loginWebCall setPostData:post];
    [[INDWebservices shared] startWebserviceOperation:loginWebCall];
}

-(void)completionOperation:(id)operation responseData:(id)responseObject webServiceOperationObject:(INDWebServiceModel *)webServiceOperationObject withError:(NSError *)error
{
    [loginLoader stopAnimating];
    [loginBtn setEnabled:YES];
    if (webServiceOperationObject.serviceName==Login) {
        AFHTTPRequestOperation* loginOperation = (AFHTTPRequestOperation*)operation;
        
        if (loginOperation.response.statusCode ==200) {
            NSURL* updateActuactorUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@getallarduinos",SERVER_URL]];
            
            INDWebServiceModel* getAllArduinos = [[INDWebServiceModel alloc] initWithDelegate:self url:updateActuactorUrl NameOfWebService:getAllArdinos];
            
            [[INDWebservices shared] startWebserviceOperation:getAllArduinos];
        }
        else
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Authentication failed" message:@"Incorret user id or password" preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    
    
    if (webServiceOperationObject.serviceName==getAllArdinos) {
        AFHTTPRequestOperation* loginOperation = (AFHTTPRequestOperation*)operation;
        
        if (loginOperation.response.statusCode ==200) {
            NSDictionary* responseDict = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
            NSArray* data =[responseDict objectForKey:@"data"];
            [self updateDatabaseWithArduniosWithArray:data];
            [self performSegueWithIdentifier:@"serverloginSegue" sender:self];

        }
        else
        {
        }
    }
}

-(void)updateDatabaseWithArduniosWithArray:(NSArray*)array
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSManagedObjectContext *context = appDelegate.managedObjectContext;
    for (NSDictionary* temp in array) {
        NSDictionary* device =[temp objectForKey:@"device"];
        HydroponicsSystem* h= [HydroponicsSystem loadHydroponicSystemWithID:[device objectForKey:@"ArduinoID"] withContext:context];
        h.plantId = [[temp objectForKey:@"plant"] objectForKey:@"plantName"];
        h.userId = [device objectForKey:@"DeviceName"];
        h.deviceId =[device objectForKey:@"ArduinoID"];
        
        NSDictionary* plantCondition = [[temp objectForKey:@"plant"] objectForKey:@"condition"];
        h.param.pHLowerThreshold = [[plantCondition objectForKey:@"ph"] objectForKey:@"low"];
        h.param.pHUpperThreshold =[[plantCondition objectForKey:@"ph"] objectForKey:@"high"];
        h.param.moistureLowerThreshold =[plantCondition objectForKey:@"moisture"];
        h.param.lightLowerThreshold =  [plantCondition objectForKey:@"light"];
        h.param.tdsLowerThreshold =[[plantCondition objectForKey:@"nutrient"] objectForKey:@"low"];
        h.param.tdsUpperThreshold =[[plantCondition objectForKey:@"nutrient"] objectForKey:@"high"];
        NSError* error;
        [context save:&error];
    }
    
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
