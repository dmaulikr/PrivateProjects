//
//  LoginVC.h
//  FogComputer
//
//  Created by Parth Kalavadia on 3/1/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController

@end
