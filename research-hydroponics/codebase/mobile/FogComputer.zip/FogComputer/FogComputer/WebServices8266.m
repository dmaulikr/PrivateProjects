//
//  WebServices8266.m
//  FogComputer
//
//  Created by Parth Kalavadia on 2/29/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import "WebServices8266.h"
#import "HTTPServer.h"
#import "HydroponicsSystem+CoreDataProperties.h"
#import "SystemLog+CoreDataProperties.h"
#import "AppDelegate.h"
#import "INDWebservices.h"
#import "Constant.h"
#import "ControlParameters+CoreDataProperties.h"
#import "UserDefault.h"
@interface WebServices8266()<webServiceResponceProtocol>


@end



@implementation WebServices8266

+ (void)load
{
    [HTTPResponseHandler registerHandler:self];
}

+ (BOOL)canHandleRequest:(CFHTTPMessageRef)aRequest
                  method:(NSString *)requestMethod
                     url:(NSURL *)requestURL
            headerFields:(NSDictionary *)requestHeaderFields
{
    if ([requestURL.path isEqualToString:@"/"])
    {
        return YES;
    }
    
    return YES;
}

//
// startResponse
//
// Since this is a simple response, we handle it synchronously by sending
// everything at once.
//
- (void)startResponse
{
  //  NSData *fileData =   [NSData dataWithContentsOfFile:[WebServices8266 pathForFile]];
    
    
    
    NSMutableDictionary *requestDict = [[NSMutableDictionary alloc] init];
    NSArray *urlComponents = [[url absoluteString] componentsSeparatedByString:@"&"];
    
    for (NSString *keyValuePair in urlComponents)
    {
        NSArray *pairComponents = [keyValuePair componentsSeparatedByString:@"="];
        NSString *key = [[pairComponents firstObject] stringByRemovingPercentEncoding];
        NSString *value = [[pairComponents lastObject] stringByRemovingPercentEncoding];
        
        [requestDict setObject:value forKey:key];
    }
    
    NSLog(@"%@",requestDict);

    
  
    NSData* payload;
    if ([[requestDict objectForKey:@"fn"] isEqualToString:@"getSensorDetails"]) {
        payload=[self updateSensorData:requestDict];

    }else
        payload=[self updateActuatorData:requestDict];
    
    
    
    
//    if (url==) {
//        <#statements#>
//    }else
//    {
//        
//    }
    
    
    
    CFHTTPMessageRef response =
    CFHTTPMessageCreateResponse(
                                kCFAllocatorDefault, 200, NULL, kCFHTTPVersion1_1);
    CFHTTPMessageSetHeaderFieldValue(
                                     response, (CFStringRef)@"Content-Type", (CFStringRef)@"application/json");
    CFHTTPMessageSetHeaderFieldValue(
                                     response, (CFStringRef)@"Connection", (CFStringRef)@"close");
    CFHTTPMessageSetHeaderFieldValue(
                                     response,
                                     (CFStringRef)@"Content-Length",
                                     (__bridge CFStringRef)[NSString stringWithFormat:@"%ld", (unsigned long)[payload length]]);
    CFDataRef headerData = CFHTTPMessageCopySerializedMessage(response);
    
    @try
    {
        [fileHandle writeData:(__bridge NSData *)headerData];
        [fileHandle writeData:payload];
    }
    @catch (NSException *exception)
    {
        NSLog(@"%@",exception);
        // Ignore the exception, it normally means the client
        // closed the connection from the other end.
    }
    @finally
    {
        CFRelease(headerData);
        [server closeHandler:self];
    }
}


-(NSData*)updateSensorData:(NSDictionary*)requestDict
{
    SensorDeviceData* sensorData = [SensorDeviceData parseSensorData:requestDict];
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSManagedObjectContext *context = appDelegate.managedObjectContext;
    HydroponicsSystem* hSystem = [HydroponicsSystem loadHydroponicSystemWithID:sensorData.deviceId withContext:context];
    
    if (hSystem==nil) {
        //create a new system and update
        //give a web call to fetch parameters
        hSystem = [NSEntityDescription insertNewObjectForEntityForName:@"HydroponicsSystem" inManagedObjectContext:context];
        hSystem.deviceId = sensorData.deviceId;
    }
    
    if (!sensorData.boot) {
        [hSystem addSensorData:sensorData withContext:context];
    }
    
    
    
    NSURL* updateLogUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@logplantupdate",SERVER_URL]];
    
    INDWebServiceModel* updateSensorWebservice = [[INDWebServiceModel alloc] initWithDelegate:self url:updateLogUrl NameOfWebService:UpdateSensorData];
    
    
    NSDictionary* conditionDict = @{@"ph":[NSNumber numberWithFloat:sensorData.pH],@"light":[NSNumber numberWithFloat:sensorData.light],@"nutrient":[NSNumber numberWithFloat:sensorData.tds],@"moisture":[NSNumber numberWithFloat:sensorData.moisture]};
    
    NSDictionary* actuatorstatusDict=@{@"PhBalance":[NSNumber numberWithBool:hSystem.param.isPHBalance],@"Nutrition":[NSNumber numberWithBool:hSystem.param.isTdsBalance],@"Moisturizer":[NSNumber numberWithBool:hSystem.param.isMoistureBalance],@"Light":[NSNumber numberWithBool:hSystem.param.isExternalLightOff]};
    
    [updateSensorWebservice setPostData:@{@"condition":conditionDict,@"actuatorstatus":actuatorstatusDict,@"ArduinoID":hSystem.deviceId,@"APNAToken": [UserDefault getDeviceToken],@"boot":[NSNumber numberWithBool: NO]}];
    [[INDWebservices shared] startWebserviceOperation:updateSensorWebservice];
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:NOTIFICATION_SENSORDATA_UPDATED object:nil];
    
    return [self getJsonDataFromDictionary:[hSystem getLatestThresholds]];
}


-(NSData*)updateActuatorData:(NSDictionary*)requestDict
{
    ActuatorDeviceStatus* systemStatus = [ActuatorDeviceStatus parseActuatorData:requestDict];
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSManagedObjectContext *context = appDelegate.managedObjectContext;

    HydroponicsSystem* hSystem = [HydroponicsSystem loadHydroponicSystemWithID:systemStatus.deviceId withContext:context];
    
    if (hSystem==nil) {
        hSystem = [NSEntityDescription insertNewObjectForEntityForName:@"HydroponicsSystem" inManagedObjectContext:context];
        hSystem.deviceId = systemStatus.deviceId;
        
    }
    
    [hSystem updateActuatorData:systemStatus withContext:context];
    NSURL* updateActuactorUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@logactuatorupdate",SERVER_URL]];
    
    INDWebServiceModel* updateSensorWebservice = [[INDWebServiceModel alloc] initWithDelegate:self url:updateActuactorUrl NameOfWebService:UpdateActuatorData];
    
    NSDictionary* actuatorstatusDict=@{@"PhBalance":[NSNumber numberWithBool:systemStatus.phBalance],@"Nutrition":[NSNumber numberWithBool:systemStatus.tdsBalance],@"Moisturizer":[NSNumber numberWithBool:systemStatus.moistureBalance],@"Light":[NSNumber numberWithBool:systemStatus.lightBalance]};
    
    [updateSensorWebservice setPostData:@{@"actuatorstatus":actuatorstatusDict,@"ArduinoId"
                                          :hSystem.deviceId}];
    [[INDWebservices shared] startWebserviceOperation:updateSensorWebservice];
    
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:NOTIFICATION_ACTUATOR_UPDATED object:nil];
    
    return [self getJsonDataFromDictionary:[hSystem getLatestThresholds]];
}

-(NSData*)getJsonDataFromDictionary:(NSDictionary*)dict
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    
    if (error!=nil) {
        return nil;
    }
    
    return jsonData;
}

-(void)completionOperation:(id)operation responseData:(id)responseObject webServiceOperationObject:(INDWebServiceModel *)webServiceOperationObject withError:(NSError *)error
{
       if (webServiceOperationObject.serviceName==Login) {
        AFHTTPRequestOperation* loginOperation = (AFHTTPRequestOperation*)operation;
        NSLog(@"login failed %ld",loginOperation.response.statusCode);
        
        if (loginOperation.response.statusCode ==200) {
            
        }
        else
        {
           
        }
    }
}



@end
