//
//  ControlParameters.m
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//

#import "ControlParameters.h"

@implementation ControlParameters

// Insert code here to add functionality to your managed object subclass

@end
