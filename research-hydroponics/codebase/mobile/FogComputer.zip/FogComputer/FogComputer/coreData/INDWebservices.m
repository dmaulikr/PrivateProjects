//
//  INDWebservices.m
//  PfizerMobileApp
//
//  Created by Ashish on 16/01/14.
//
//

#import "INDWebservices.h"


@implementation INDWebservices

+ (INDWebservices*)shared {
    
    static INDWebservices *sharedclass = nil;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        sharedclass = [[self alloc] init];
    });
    
    return sharedclass;
}

- (id)init {
    
    if (self = [super init]) {
        
    }
    
    return self;
}

-(void)startWebserviceOperation: (INDWebServiceModel*) webserviceOperationObject
{
    if (webserviceOperationObject.postData)
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager POST:[webserviceOperationObject.url absoluteString]  parameters:webserviceOperationObject.postData success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
                [webserviceOperationObject.delegate completionOperation:operation responseData:responseObject webServiceOperationObject:webserviceOperationObject withError:nil];
          //   if ([webserviceOperationObject.delegate respondsToSelector:@selector(completionOperation:responseData:webServiceOperationObject:withError:)])
              
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             
             if([webserviceOperationObject.delegate respondsToSelector:@selector(completionOperation:responseData:webServiceOperationObject:withError:)])
                 [webserviceOperationObject.delegate completionOperation:operation responseData:nil webServiceOperationObject:webserviceOperationObject withError:error];
         }];
        
    } else {
        
        
        NSMutableURLRequest* urlRequest=[NSMutableURLRequest requestWithURL:webserviceOperationObject.url];
        
        if (webserviceOperationObject.soapMessage) {
            NSString *msgLength = [NSString stringWithFormat:@"%lu", (unsigned long)[webserviceOperationObject.soapMessage length]];
            
            [urlRequest addValue: webserviceOperationObject.contenttype forHTTPHeaderField:@"Content-Type"];
            if (webserviceOperationObject.soapAction !=nil) {
                [urlRequest addValue: webserviceOperationObject.soapAction forHTTPHeaderField:@"SOAPAction"];
            }
            
            [urlRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
            [urlRequest setHTTPMethod:@"POST"];
            [urlRequest setHTTPBody: [webserviceOperationObject.soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
        }
        
        AFHTTPRequestOperation* operation=[[AFHTTPRequestOperation alloc] initWithRequest:urlRequest];
        
     
        
        webserviceOperationObject.operation=operation;
        
        [operation setShouldExecuteAsBackgroundTaskWithExpirationHandler:nil];
        
        if (webserviceOperationObject.downloadPath!=nil) {
            
            operation.outputStream=[NSOutputStream outputStreamToFileAtPath:webserviceOperationObject.downloadPath append:YES];
            
            if (![[NSFileManager defaultManager] fileExistsAtPath:[webserviceOperationObject.downloadPath stringByDeletingLastPathComponent]])
                
                [[NSFileManager defaultManager] createDirectoryAtPath:[webserviceOperationObject.downloadPath stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
            
        }
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            if ([webserviceOperationObject.delegate respondsToSelector:@selector(completionOperation:responseData:webServiceOperationObject:withError:)])
                [webserviceOperationObject.delegate completionOperation:operation responseData:responseObject webServiceOperationObject:webserviceOperationObject withError:nil];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if([webserviceOperationObject.delegate respondsToSelector:@selector(completionOperation:responseData:webServiceOperationObject:withError:)])
                [webserviceOperationObject.delegate completionOperation:operation responseData:nil webServiceOperationObject:webserviceOperationObject withError:error];
                
        }];
        
        [operation setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
            
            if([webserviceOperationObject.delegate respondsToSelector:@selector(downloadProgress:totalBytesRead:totalBytesExpectedToRead:)])
                [webserviceOperationObject.delegate downloadProgress:bytesRead totalBytesRead:totalBytesRead totalBytesExpectedToRead:totalBytesExpectedToRead];
        }];
        
        [operation start];
    }
}


-(void)cancelOperation: (INDWebServiceModel*) webserviceOperationObject
{
    webserviceOperationObject.delegate = nil;
    
    if ([webserviceOperationObject.operation isExecuting])
        [webserviceOperationObject.operation cancel];
}

//Alert Message Methods

//-(void)message:(NSString*)msg
//{
//    
//    /*
//    UIAlertController*alertcontroller = [UIAlertController alertControllerWithTitle:@"Message" message:msg preferredStyle:UIAlertControllerStyleAlert];
//   
//    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
//                                                          handler:^(UIAlertAction * action) {
//                                                          
//                                                          }];
//    
//     [self presentViewController:alertcontroller animated:YES completion:nil];
//    */
//    
//    
//    UIAlertView*msgAlertView= [[UIAlertView alloc]initWithTitle:@"Message" message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
//    
//    [msgAlertView show];
//    
//    [self performSelector:@selector(cancelAlert:) withObject:msgAlertView afterDelay:3.0];
//    
//    
//    
//    
//
//}
//
//-(void)cancelAlert:(UIAlertView*)alert
//{
//    
//    [alert dismissWithClickedButtonIndex:0 animated:YES];
//    
//}
-(void)pauseOperation: (INDWebServiceModel*) webserviceOperationObject
{
    if ([webserviceOperationObject.operation isExecuting]) {
        
        [webserviceOperationObject.operation pause];
        
    }
}

-(void)resumeOperation: (INDWebServiceModel*) webserviceOperationObject
{
    [webserviceOperationObject.operation resume];
}
-(BOOL)isWebServiceOperationExecuting: (INDWebServiceModel*)webServiceModel
{
    return [webServiceModel.operation isExecuting];
}

@end
