//
//  SystemLog+CoreDataProperties.h
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "SystemLog.h"

NS_ASSUME_NONNULL_BEGIN

@interface SystemLog (CoreDataProperties)

@property (nullable, nonatomic, retain) NSDate *date;
@property (nullable, nonatomic, retain) NSNumber *light;
@property (nullable, nonatomic, retain) NSNumber *loggedOnServer;
@property (nullable, nonatomic, retain) NSNumber *moisture;
@property (nullable, nonatomic, retain) NSNumber *pH;
@property (nullable, nonatomic, retain) NSNumber *temp;

@end

NS_ASSUME_NONNULL_END
