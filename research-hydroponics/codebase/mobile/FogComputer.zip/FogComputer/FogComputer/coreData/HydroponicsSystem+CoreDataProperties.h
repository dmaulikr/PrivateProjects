//
//  HydroponicsSystem+CoreDataProperties.h
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "HydroponicsSystem.h"

NS_ASSUME_NONNULL_BEGIN

@interface HydroponicsSystem (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *deviceId;
@property (nullable, nonatomic, retain) NSString *plantId;
@property (nullable, nonatomic, retain) NSString *userId;
@property (nullable, nonatomic, retain) NSOrderedSet<SystemLog *> *log;
@property (nullable, nonatomic, retain) ControlParameters *param;

@end

@interface HydroponicsSystem (CoreDataGeneratedAccessors)

- (void)insertObject:(SystemLog *)value inLogAtIndex:(NSUInteger)idx;
- (void)removeObjectFromLogAtIndex:(NSUInteger)idx;
- (void)insertLog:(NSArray<SystemLog *> *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeLogAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInLogAtIndex:(NSUInteger)idx withObject:(SystemLog *)value;
- (void)replaceLogAtIndexes:(NSIndexSet *)indexes withLog:(NSArray<SystemLog *> *)values;
- (void)addLogObject:(SystemLog *)value;
- (void)removeLogObject:(SystemLog *)value;
- (void)addLog:(NSOrderedSet<SystemLog *> *)values;
- (void)removeLog:(NSOrderedSet<SystemLog *> *)values;

@end

NS_ASSUME_NONNULL_END
