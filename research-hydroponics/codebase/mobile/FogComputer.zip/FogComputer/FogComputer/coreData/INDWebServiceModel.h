//
//  INDWebServiceModel.h
//  PfizerMobileApp
//
//  Created by parth on 17/01/14.
//
//

#import <Foundation/Foundation.h>
#import "AFHTTPRequestOperation.h"
@class INDWebServiceModel;

@protocol webServiceResponceProtocol <NSObject>

@optional
-(void)completionOperation: (id)operation responseData:(id)responseObject webServiceOperationObject:(INDWebServiceModel*) webServiceOperationObject withError:(NSError*)error;

-(void)downloadProgress:(NSUInteger) bytesRead  totalBytesRead: (long long)tbytes totalBytesExpectedToRead: (long long) tbytesExpected;
@end


typedef enum {
    Login=1,
    UpdateSensorData,
    UpdateActuatorData,
    updateToken,
    getAllArdinos
}webServiceName;

@interface INDWebServiceModel : NSObject

@property (strong,nonatomic) NSURL* url;
@property (weak)id<webServiceResponceProtocol>delegate;
@property (assign,nonatomic)webServiceName serviceName;
@property (strong,nonatomic)AFHTTPRequestOperation* operation;
@property (strong,nonatomic) NSDictionary*postData;
@property (strong,nonatomic)NSString* downloadPath;
@property (assign,nonatomic)NSString* soapMessage;
@property (assign,nonatomic)NSString* contenttype;
@property (assign,nonatomic)NSString* soapAction;

//if we have to call get Request use this
-(id)initWithDelegate: (id)delgate url: (NSURL*)serviceUrl NameOfWebService: (webServiceName) webServiceName;

//if we have to call Soap Request use this
-(id)initForSoapRequestWithDelegate: (id)delgate url: (NSURL*)serviceUrl soapMessage:(NSString*)soapmessage withContentType:(NSString*)contenttype withSoapAction:(NSString*)soapaction NameOfWebService: (webServiceName) webServiceName;
@end