//
//  HydroponicsSystem.m
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//

#import "HydroponicsSystem.h"
#import "ControlParameters.h"
#import "SystemLog.h"

// Insert code here to add functionality to your managed object subclass

@implementation SensorDeviceData

+(SensorDeviceData*)parseSensorData:(NSDictionary*)dict
{
    SensorDeviceData* sensorData = [[SensorDeviceData alloc] init];
    
    sensorData.deviceId = [dict objectForKey:@"sensorId"];
    sensorData.pH       = [[dict objectForKey:@"ph"] floatValue];
    sensorData.tds      = [[dict objectForKey:@"tds"] floatValue];
    sensorData.temperature=[[dict objectForKey:@"temperature"] floatValue];
    sensorData.light    = [[dict objectForKey:@"light"] floatValue];
    sensorData.moisture = [[dict objectForKey:@"moisture"] floatValue];
    sensorData.boot     = [[dict objectForKey:@"boot"] boolValue];
    
    return sensorData;
}

@end

@implementation ActuatorDeviceStatus

+(ActuatorDeviceStatus*)parseActuatorData:(NSDictionary*)dict
{
    ActuatorDeviceStatus* actuatorData = [[ActuatorDeviceStatus alloc] init];
    
    actuatorData.deviceId = [dict objectForKey:@"sensorId"];
    actuatorData.phBalance       = [[dict objectForKey:@"isPhBalance"] boolValue];
    actuatorData.tdsBalance      = [[dict objectForKey:@"isTdsBalance"] floatValue];
    actuatorData.temperatureBalance=[[dict objectForKey:@"isTemperatureBalance"] floatValue];
    actuatorData.lightBalance    = [[dict objectForKey:@"isLightBalance"] floatValue];
    actuatorData.moistureBalance = [[dict objectForKey:@"isMoistureBalance"] floatValue];
    
    return actuatorData;
}
@end

@implementation SensorThresholds

+(SensorThresholds*)parseSensorThresholds:(NSDictionary *)dict
{
    SensorThresholds* sensorThreshold = [[SensorThresholds alloc] init];
    sensorThreshold.lightLowerThreshold = [[dict objectForKey:@"light"] floatValue];
    sensorThreshold.moistureLowerThreshold = [[dict objectForKey:@"moisture"] floatValue];
    sensorThreshold.pHLowerThreshold = [[dict objectForKey:@"phl"] floatValue];
    sensorThreshold.pHUpperThreshold = [[dict objectForKey:@"phh"] floatValue];
    sensorThreshold.tdsLowerThreshold = [[dict objectForKey:@"nutrientl"] floatValue];
    sensorThreshold.tdsUpperThreshold = [[dict objectForKey:@"nutrienth"] floatValue];
    //sensorThreshold.
    return sensorThreshold;
}


@end


@implementation HydroponicsSystem

// Insert code here to add functionality to your managed object subclass

+(HydroponicsSystem*)loadHydroponicSystemWithID:(NSString*)deviceId withContext:(NSManagedObjectContext*)context{
    NSError *error;
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"HydroponicsSystem"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"deviceId = %@",deviceId];
    [request setPredicate:predicate];
    NSArray *results = [context executeFetchRequest:request error:&error];
    
    if([results count]>0) {
        HydroponicsSystem* system = [results firstObject];
        return system;
    } else {
        NSLog(@"Error: %@", error);
    }
    
    HydroponicsSystem* hSystem = [NSEntityDescription insertNewObjectForEntityForName:@"HydroponicsSystem" inManagedObjectContext:context];
    hSystem.param = [NSEntityDescription insertNewObjectForEntityForName:@"ControlParameters" inManagedObjectContext:context];
    hSystem.param.isExternalLightOff = [NSNumber numberWithBool: YES];
    hSystem.param.isMoistureBalance   =[NSNumber numberWithBool: YES];
    hSystem.param.isPHBalance         = [NSNumber numberWithBool: YES];
    hSystem.param.isTdsBalance        = [NSNumber numberWithBool: YES];
    hSystem.deviceId = deviceId;
    [context save:&error];
    return hSystem;
}

+(NSArray*)getAllDeviceIdWithContext:(NSManagedObjectContext*)context
{
    
    NSMutableArray* deviceIds = [NSMutableArray new];
    
    NSArray* results=[self getAllHydroponicSystems:context];
    for (HydroponicsSystem*hydroponicS in results) {
        [deviceIds addObject: hydroponicS.deviceId];
    }
    
    return [NSArray arrayWithArray:deviceIds];
}

-(void)addSensorData:(SensorDeviceData*)sensorData withContext:(NSManagedObjectContext*)context
{
    SystemLog* log = [NSEntityDescription insertNewObjectForEntityForName:@"SystemLog" inManagedObjectContext:context];
    
    log.date    = [NSDate date];
    log.pH      = [NSNumber numberWithFloat:sensorData.pH];
    log.light   = [NSNumber numberWithFloat:sensorData.light];
    log.temp    = [NSNumber numberWithFloat:sensorData.temperature];
    log.moisture= [NSNumber numberWithFloat:sensorData.moisture];
    [self addLogObject:log];
    
    NSError* error;
    [context save:&error];
}



-(void)updateActuatorData:(ActuatorDeviceStatus*)systemStatus withContext:(NSManagedObjectContext*)context
{
    
    if (self.param==nil) {
        self.param = [NSEntityDescription insertNewObjectForEntityForName:@"ControlParameters" inManagedObjectContext:context];
    }
    
    self.param.isExternalLightOff = [NSNumber numberWithBool: systemStatus.lightBalance];
    self.param.isPHBalance        = [NSNumber numberWithBool: systemStatus.phBalance];
    self.param.isTdsBalance       = [NSNumber numberWithBool: systemStatus.tdsBalance];
    self.param.isMoistureBalance  = [NSNumber numberWithBool: systemStatus.moistureBalance];
    NSError* error;
    [context save:&error];
}

-(void)updateSensorThresholds:(SensorThresholds *)sensorThreshold withContext:(NSManagedObjectContext *)context
{
    ControlParameters* parameter = (ControlParameters*)self.param;
    
    if (parameter==nil) {
        parameter = [NSEntityDescription insertNewObjectForEntityForName:@"ControlParameters" inManagedObjectContext:context];
        
        parameter.isExternalLightOff = [NSNumber numberWithBool: YES];
        parameter.isMoistureBalance   =[NSNumber numberWithBool: YES];
        parameter.isPHBalance         = [NSNumber numberWithBool: YES];
        parameter.isTdsBalance        = [NSNumber numberWithBool: YES];
    }
    
    parameter.lightLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.lightLowerThreshold];
    parameter.moistureLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.moistureLowerThreshold];
    parameter.pHUpperThreshold = [NSNumber numberWithFloat: sensorThreshold.pHUpperThreshold];
    parameter.pHLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.pHLowerThreshold];
    parameter.tdsUpperThreshold = [NSNumber numberWithFloat: sensorThreshold.tdsUpperThreshold];
    parameter.tdsLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.tdsLowerThreshold];
    self.param = parameter;
    NSError* error;
    [context save:&error];
}

-(NSDictionary*)getLatestThresholds{
    
    
    
    NSMutableDictionary* systemThresholdsDict = [NSMutableDictionary new];
    
 
    
    [systemThresholdsDict setObject:self.param.lightLowerThreshold forKey:@"lightLowerThresholds"];
    [systemThresholdsDict setObject:self.param.moistureLowerThreshold forKey:@"moistureLowerThresholds"];
    [systemThresholdsDict setObject:self.param.pHLowerThreshold forKey:@"phLowerThresholds"];
    [systemThresholdsDict setObject:self.param.pHUpperThreshold forKey:@"phUpperThresholds"];
    [systemThresholdsDict setObject:self.param.tdsLowerThreshold forKey:@"tdsLowerThresholds"];
    [systemThresholdsDict setObject:self.param.tdsUpperThreshold forKey:@"tdsUpperThresholds"];
 
    
    if (self.param==nil) {
        [systemThresholdsDict setObject:[NSNumber numberWithInt:0] forKey:@"valid"];
    }else
        [systemThresholdsDict setObject:[NSNumber numberWithInt:1] forKey:@"valid"];
    
    
    return [NSDictionary dictionaryWithDictionary: systemThresholdsDict];
}

+(NSArray*)getAllHydroponicSystems:(NSManagedObjectContext*)context{
    NSError* error;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"HydroponicsSystem"];
    NSArray *results = [context executeFetchRequest:request error:&error];
    return results;
}

@end

