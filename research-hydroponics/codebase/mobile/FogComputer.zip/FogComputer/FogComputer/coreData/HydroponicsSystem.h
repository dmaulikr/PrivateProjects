//
//  HydroponicsSystem.h
//  FogComputer
//
//  Created by Parth Kalavadia on 2/25/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class ControlParameters, SystemLog;

NS_ASSUME_NONNULL_BEGIN
@interface SensorDeviceData: NSObject
@property(strong,nonatomic)NSString* deviceId;
@property(assign,nonatomic)float pH;
@property(assign,nonatomic)float tds;
@property(assign,nonatomic)float moisture;
@property(assign,nonatomic)float temperature;
@property(assign,nonatomic)float light;
@property(assign,nonatomic)BOOL boot;

+(SensorDeviceData*)parseSensorData:(NSDictionary*)dict;
@end

@interface ActuatorDeviceStatus : NSObject
@property(strong,nonatomic)NSString* deviceId;
@property(assign,nonatomic)BOOL phBalance;
@property(assign,nonatomic)BOOL tdsBalance;
@property(assign,nonatomic)BOOL moistureBalance;
@property(assign,nonatomic)BOOL temperatureBalance;
@property(assign,nonatomic)BOOL lightBalance;
+(ActuatorDeviceStatus*)parseActuatorData:(NSDictionary*)dict;
@end

@interface SensorThresholds : NSObject
@property (nonatomic) float lightLowerThreshold;
@property (nonatomic) float moistureLowerThreshold;
@property (nonatomic) float pHLowerThreshold;
@property (nonatomic) float pHUpperThreshold;
@property (nonatomic) float tdsLowerThreshold;
@property (nonatomic) float tdsUpperThreshold;
+(SensorThresholds*)parseSensorThresholds:(NSDictionary*)dict;

@end

@interface HydroponicsSystem : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

+(HydroponicsSystem*)loadHydroponicSystemWithID:(NSString*)Id withContext:(NSManagedObjectContext*)context;
-(void)addSensorData:(SensorDeviceData*)sensorData withContext:(NSManagedObjectContext*)context;
-(void)updateActuatorData:(ActuatorDeviceStatus*)systemStatus withContext:(NSManagedObjectContext*)context;
-(void)updateSensorThresholds:(SensorThresholds*)sensorThreshold withContext:(NSManagedObjectContext*)context;
+(NSArray*)getAllDeviceIdWithContext:(NSManagedObjectContext*)context;
+(NSArray*)getAllHydroponicSystems:(NSManagedObjectContext*)context;
-(NSDictionary*)getLatestThresholds;
@end

NS_ASSUME_NONNULL_END

#import "HydroponicsSystem+CoreDataProperties.h"