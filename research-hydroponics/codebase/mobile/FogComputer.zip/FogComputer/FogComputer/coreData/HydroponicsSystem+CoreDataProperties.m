//
//  HydroponicsSystem+CoreDataProperties.m
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "HydroponicsSystem+CoreDataProperties.h"

@implementation HydroponicsSystem (CoreDataProperties)

@dynamic deviceId;
@dynamic plantId;
@dynamic userId;
@dynamic log;
@dynamic param;

@end
