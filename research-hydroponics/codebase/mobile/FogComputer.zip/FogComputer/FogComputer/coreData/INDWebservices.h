//
//  INDWebservices.h
//  PfizerMobileApp
//
//  Created by Ashish on 16/01/14.
//
//

#import <Foundation/Foundation.h>
#import <AFNetworking.h>
#import "INDWebServiceModel.h"
@interface INDWebservices : NSObject


+(INDWebservices*)shared;
-(id)init;
-(void)startWebserviceOperation: (INDWebServiceModel*) webserviceOperationObject;
-(void)cancelOperation: (INDWebServiceModel*) webserviceOperationObject;
//-(void)message:(NSString*)msg;
-(void)pauseOperation: (INDWebServiceModel*) webserviceOperationObject;
-(void)resumeOperation: (INDWebServiceModel*) webserviceOperationObject;
-(BOOL)isWebServiceOperationExecuting: (INDWebServiceModel*)webServiceModel;
@end
