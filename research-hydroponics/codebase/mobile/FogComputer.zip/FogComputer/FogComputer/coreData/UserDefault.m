//
//  UserDefault.m
//  FogComputer
//
//  Created by Parth Kalavadia on 2/29/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import "UserDefault.h"

#define USER_NAME_KEY @"username"
#define PASSWORD_KEY @"password"
#define TOKEN @"token"
#define SESSION_ID @"sessionId"

@implementation UserDefault

+ (UserDefault*)shared
{
    
    static UserDefault *sharedclass = nil;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        sharedclass = [[self alloc] init];
    });
    
    return sharedclass;
}

-(void)setUserDefault:(id)object forKey:(NSString*)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:object forKey:key];
    [defaults synchronize];
}

-(id)getUserDefaultForKey:(NSString*)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    id object = [defaults objectForKey:key];
    
    return object;
}

+(NSString*)getAdminUserName{
    
    return (NSString*)[[UserDefault shared] getUserDefaultForKey:USER_NAME_KEY];
    
}

+(void)setAdminUserName:(NSString*)username{
    [[UserDefault shared] setUserDefault:username forKey:USER_NAME_KEY];
}


+(NSString*)getAdminPassword{
    
    return (NSString*)[[UserDefault shared] getUserDefaultForKey:PASSWORD_KEY];

}

+(void)setAdminPassword:(NSString*)password{
    
    [[UserDefault shared] setUserDefault:password forKey:PASSWORD_KEY];
}

+(NSString*)getDeviceToken{
    
    return (NSString*)[[UserDefault shared] getUserDefaultForKey:TOKEN];
    
}

+(void)setDeviceToken:(NSString*)token{
    
    [[UserDefault shared] setUserDefault:token forKey:TOKEN];
}

+(NSString*)getSessionId{
    
    return (NSString*)[[UserDefault shared] getUserDefaultForKey:SESSION_ID];
    
}

+(void)saveSessionId:(NSString*)sessionId
{
    
    [[UserDefault shared] setUserDefault:sessionId forKey:SESSION_ID];
}

@end
