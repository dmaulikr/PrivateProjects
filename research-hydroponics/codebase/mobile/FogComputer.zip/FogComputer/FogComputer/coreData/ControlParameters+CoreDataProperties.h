//
//  ControlParameters+CoreDataProperties.h
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "ControlParameters.h"

NS_ASSUME_NONNULL_BEGIN

@interface ControlParameters (CoreDataProperties)

@property (nullable, nonatomic, retain) NSNumber *isExternalLightOff;
@property (nullable, nonatomic, retain) NSNumber *isMoistureBalance;
@property (nullable, nonatomic, retain) NSNumber *isPHBalance;
@property (nullable, nonatomic, retain) NSNumber *isTdsBalance;
@property (nullable, nonatomic, retain) NSNumber *lightLowerThreshold;
@property (nullable, nonatomic, retain) NSNumber *moistureLowerThreshold;
@property (nullable, nonatomic, retain) NSNumber *pHLowerThreshold;
@property (nullable, nonatomic, retain) NSNumber *pHUpperThreshold;
@property (nullable, nonatomic, retain) NSNumber *tdsLowerThreshold;
@property (nullable, nonatomic, retain) NSNumber *tdsUpperThreshold;

@end

NS_ASSUME_NONNULL_END
