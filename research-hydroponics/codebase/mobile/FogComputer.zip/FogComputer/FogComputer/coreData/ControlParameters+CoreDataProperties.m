//
//  ControlParameters+CoreDataProperties.m
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "ControlParameters+CoreDataProperties.h"

@implementation ControlParameters (CoreDataProperties)

@dynamic isExternalLightOff;
@dynamic isMoistureBalance;
@dynamic isPHBalance;
@dynamic isTdsBalance;
@dynamic lightLowerThreshold;
@dynamic moistureLowerThreshold;
@dynamic pHLowerThreshold;
@dynamic pHUpperThreshold;
@dynamic tdsLowerThreshold;
@dynamic tdsUpperThreshold;

@end
