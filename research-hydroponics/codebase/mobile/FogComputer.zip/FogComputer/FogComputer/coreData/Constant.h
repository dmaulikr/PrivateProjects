//
//  Constant.h
//  FogComputer
//
//  Created by Parth Kalavadia on 3/1/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

#define SERVER_URL @"http://api.humandroid.us/api/"

#define NOTIFICATION_SENSORDATA_UPDATED @"sensor_data_updated"
#define NOTIFICATION_ACTUATOR_UPDATED @"actuator_data_updated"
#define NOTIFICATION_USER_UPDATED @"user_data_updated"


#endif /* Constant_h */
