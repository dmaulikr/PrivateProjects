//
//  UserDefault.h
//  FogComputer
//
//  Created by Parth Kalavadia on 2/29/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserDefault : NSObject
+ (UserDefault*)shared;
-(void)setUserDefault:(id)object forKey:(NSString*)key;
-(id)getUserDefaultForKey:(NSString*)key;
+(NSString*)getAdminUserName;+(void)setAdminUserName:(NSString*)username;
+(NSString*)getAdminPassword;
+(void)setAdminPassword:(NSString*)password;
+(NSString*)getDeviceToken;
+(void)setDeviceToken:(NSString*)token;
@end
