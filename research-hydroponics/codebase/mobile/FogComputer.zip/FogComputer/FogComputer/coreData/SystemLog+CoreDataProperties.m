//
//  SystemLog+CoreDataProperties.m
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "SystemLog+CoreDataProperties.h"

@implementation SystemLog (CoreDataProperties)

@dynamic date;
@dynamic light;
@dynamic loggedOnServer;
@dynamic moisture;
@dynamic pH;
@dynamic temp;

@end
