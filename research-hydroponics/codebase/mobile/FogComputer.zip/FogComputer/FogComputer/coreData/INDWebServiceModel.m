//
//  INDWebServiceModel.m
//  PfizerMobileApp
//
//  Created by parth on 17/01/14.
//
//

#import "INDWebServiceModel.h"

@interface INDWebServiceModel ()
@end


@implementation INDWebServiceModel
@synthesize serviceName;
@synthesize operation;

-(id)initWithDelegate: (id)delgate url: (NSURL*)serviceUrl NameOfWebService: (webServiceName) webServiceName
{
    self = [super init];
    self.delegate=delgate;
    self.url=serviceUrl;
    serviceName=webServiceName;
    return self;

}

-(id)initForSoapRequestWithDelegate: (id)delgate url: (NSURL*)serviceUrl soapMessage:(NSString*)soapmessage withContentType:(NSString*)contenttype withSoapAction:(NSString*)soapaction NameOfWebService: (webServiceName) webServiceName
{
    self=[super init];
    
    self.delegate=delgate;
    self.url=serviceUrl;
    self.soapMessage=soapmessage;
    self.contenttype=contenttype;
    self.soapAction=soapaction;
    self.serviceName=webServiceName;
    
    return self;
}

@end
