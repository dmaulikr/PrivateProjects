//
//  SystemLog.m
//  
//
//  Created by Parth Kalavadia on 3/18/16.
//
//

#import "SystemLog.h"

@implementation SystemLog

// Insert code here to add functionality to your managed object subclass

@end
