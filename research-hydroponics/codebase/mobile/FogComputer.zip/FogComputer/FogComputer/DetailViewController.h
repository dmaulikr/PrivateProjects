//
//  DetailViewController.h
//  FogComputer
//
//  Created by Parth Kalavadia on 3/17/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HydroponicsSystem.h"
@interface DetailViewController : UIViewController
@property (nonatomic,strong)HydroponicsSystem* hSystem;
@end
