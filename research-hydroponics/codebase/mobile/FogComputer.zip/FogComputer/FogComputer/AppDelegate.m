//
//  AppDelegate.m
//  FogComputer
//
//  Created by Parth Kalavadia on 2/10/16.
//  Copyright © 2016 Parth Kalavadia. All rights reserved.
//

#import "AppDelegate.h"
#import "HTTPServer.h"
#import "HTTPResponseHandler.h"
#import "UserDefault.h"
#import <AFNetworking/AFNetworking.h>
#import "INDWebservices.h"
#import "Constant.h"
#import "HydroponicsSystem+CoreDataProperties.h"
#import "ControlParameters+CoreDataProperties.h"
@interface AppDelegate ()
@end

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //[self test];

    
    [[HTTPServer sharedHTTPServer] start];
    
    
    [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    return YES;
}


-(void) application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    
    NSLog(@"%@",userInfo);
    NSDictionary* userInformation = [userInfo objectForKey:@"data"];
    HydroponicsSystem* hSystem = [HydroponicsSystem loadHydroponicSystemWithID:[userInformation objectForKey:@"AID"] withContext:[self managedObjectContext]];
    
    hSystem.plantId = [[userInformation objectForKey:@"Plant"] objectForKey:@"name"];
    hSystem.userId = [userInformation objectForKey:@"DN"];
    
    SensorThresholds* sensorThreshold = [SensorThresholds parseSensorThresholds:[userInformation objectForKey:@"plant"]];
    
    [hSystem updateSensorThresholds:sensorThreshold withContext:[self managedObjectContext]];
    

    
    ControlParameters* parameter = (ControlParameters*)hSystem.param;
    
    if (parameter==nil) {
        parameter = [NSEntityDescription insertNewObjectForEntityForName:@"ControlParameters" inManagedObjectContext:[self managedObjectContext]];
        
        parameter.isExternalLightOff = [NSNumber numberWithBool: YES];
        parameter.isMoistureBalance   =[NSNumber numberWithBool: YES];
        parameter.isPHBalance         = [NSNumber numberWithBool: YES];
        parameter.isTdsBalance        = [NSNumber numberWithBool: YES];
    }
    
    parameter.lightLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.lightLowerThreshold];
    parameter.moistureLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.moistureLowerThreshold];
    parameter.pHUpperThreshold = [NSNumber numberWithFloat: sensorThreshold.pHUpperThreshold];
    parameter.pHLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.pHLowerThreshold];
    parameter.tdsUpperThreshold = [NSNumber numberWithFloat: sensorThreshold.tdsUpperThreshold];
    parameter.tdsLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.tdsLowerThreshold];
    hSystem.param = parameter;
    
    NSError* error;
    [[self managedObjectContext] save:&error];
    [[NSNotificationCenter defaultCenter]
     postNotificationName:NOTIFICATION_USER_UPDATED object:nil];
    
}

-(void)test
{
//    HydroponicsSystem* hSystem = [HydroponicsSystem loadHydroponicSystemWithID:@"ESP001" withContext:[self managedObjectContext]];
//    hSystem.plantId = @"roofTop";
//    hSystem.userId = @"Parth";
//    
//    
//    NSDictionary* dict = @{@"moisture":@1.00,@"phl":@9.88,@"phh":@47.55,@"nutrientl":@3.99,@"nutrienth":@8.9,@"light":@22.9};
//    SensorThresholds* sensorThreshold = [SensorThresholds parseSensorThresholds:dict];
//
//    [hSystem updateSensorThresholds:sensorThreshold withContext:[self managedObjectContext]];
//
////    ControlParameters* parameter = (ControlParameters*)hSystem.param;
////    
////
////    
////    parameter.lightLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.lightLowerThreshold];
////    parameter.moistureLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.moistureLowerThreshold];
////    parameter.pHUpperThreshold = [NSNumber numberWithFloat: sensorThreshold.pHUpperThreshold];
////    parameter.pHLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.pHLowerThreshold];
////    parameter.tdsUpperThreshold = [NSNumber numberWithFloat: sensorThreshold.tdsUpperThreshold];
////    parameter.tdsLowerThreshold = [NSNumber numberWithFloat: sensorThreshold.tdsLowerThreshold];
////    hSystem.param = parameter;
////    
//    NSLog(@"%@",hSystem.param.pHLowerThreshold);
//    
//    NSError* error;
//    [[self managedObjectContext] save:&error];
    
    
    
   // NSDictionary* dict = @{@"moisture":@1.00,@"phl":@9.88,@"phh":@47.55,@"nutrientl":@3.99,@"nutrienth":@8.9,@"light":@22.9};
    
    NSURL* updateLogUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@logplantupdate",SERVER_URL]];
    
    INDWebServiceModel* updateSensorWebservice = [[INDWebServiceModel alloc] initWithDelegate:self url:updateLogUrl NameOfWebService:UpdateSensorData];
    
    
    NSDictionary* conditionDict = @{@"ph":@7.9,@"light":@78,@"nutrient":@69,@"moisture":@78};
    
    NSDictionary* actuatorstatusDict=@{@"PhBalance":[NSNumber numberWithBool:YES],@"Nutrition":[NSNumber numberWithBool:YES],@"Moisturizer":[NSNumber numberWithBool:YES],@"Light":[NSNumber numberWithBool:YES]};
    
    [updateSensorWebservice setPostData:@{@"condition":conditionDict,@"actuatorstatus":actuatorstatusDict,@"ArduinoID":@"ESP001",@"APNAToken": [UserDefault getDeviceToken],@"boot":[NSNumber numberWithBool: NO]}];
    
    NSLog(@"%@",@{@"condition":conditionDict,@"actuatorstatus":actuatorstatusDict,@"ArduinoID":@"ESP001",@"APNAToken": [UserDefault getDeviceToken],@"boot":[NSNumber numberWithBool: NO]});
    [[INDWebservices shared] startWebserviceOperation:updateSensorWebservice];
    
    
    
    
    
    
}

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}


- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    const unsigned *tokenBytes = [deviceToken bytes];
    NSString *strToken = [[NSString alloc] initWithFormat:@"%08x%08x%08x%08x%08x%08x%08x%08x",
                          ntohl(tokenBytes[0]), ntohl(tokenBytes[1]), ntohl(tokenBytes[2]),
                          ntohl(tokenBytes[3]), ntohl(tokenBytes[4]), ntohl(tokenBytes[5]),
                          ntohl(tokenBytes[6]), ntohl(tokenBytes[7])];
    [UserDefault setDeviceToken:strToken];
    NSLog(@"Tokens %@",strToken);
//    NSURL* updateTokenUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@apnatoken",SERVER_URL]];
//    
//    INDWebServiceModel* updateTokenOperation = [[INDWebServiceModel alloc] initWithDelegate:self url:updateTokenUrl NameOfWebService:updateToken];
//    
//    
//    NSArray* deviceIds = [HydroponicsSystem getAllDeviceIdWithContext:self.managedObjectContext];
//    NSDictionary* tokenDictionary = @{@"apnatoken":strToken,@"devices":deviceIds};
//    
//    [updateTokenOperation setPostData:tokenDictionary];
//    [[INDWebservices shared] startWebserviceOperation:updateTokenOperation];
    
    
    
    NSURL* updateActuactorUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@logactuatorupdate",SERVER_URL]];
    
    INDWebServiceModel* updateSensorWebservice = [[INDWebServiceModel alloc] initWithDelegate:self url:updateActuactorUrl NameOfWebService:UpdateActuatorData];
    
    NSDictionary* actuatorstatusDict=@{@"PhBalance":[NSNumber numberWithBool:YES],@"Nutrition":
                                           [NSNumber numberWithBool:YES],@"Moisturizer":[NSNumber numberWithBool:YES],@"Light":[NSNumber numberWithBool:YES]};
    
    [updateSensorWebservice setPostData:@{@"actuatorstatus":actuatorstatusDict,@"ArduinoId"
                                          :@"ESP001"}];
    [[INDWebservices shared] startWebserviceOperation:updateSensorWebservice];
    
    
    
}

-(void)completionOperation:(id)operation responseData:(id)responseObject webServiceOperationObject:(INDWebServiceModel *)webServiceOperationObject withError:(NSError *)error
{
    AFHTTPRequestOperation* x = operation;
    NSLog(@"%ld",x.response.statusCode);
    
    NSLog(@"%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
}



- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.

}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.

}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    // Saves changes in the application's managed object context before the application terminates.
    [[HTTPServer sharedHTTPServer] stop];

    [self saveContext];
}

#pragma mark - Core Data stack

@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

- (NSURL *)applicationDocumentsDirectory {
    // The directory the application uses to store the Core Data store file. This code uses a directory named "iotHydroponics.FogComputer" in the application's documents directory.
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSManagedObjectModel *)managedObjectModel {
    // The managed object model for the application. It is a fatal error for the application not to be able to find and load its model.
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"FogComputer" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    // The persistent store coordinator for the application. This implementation creates and returns a coordinator, having added the store for the application to it.
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    
    // Create the coordinator and store
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"FogComputer.sqlite"];
    NSError *error = nil;
    NSString *failureReason = @"There was an error creating or loading the application's saved data.";
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        // Report any error we got.
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[NSLocalizedDescriptionKey] = @"Failed to initialize the application's saved data";
        dict[NSLocalizedFailureReasonErrorKey] = failureReason;
        dict[NSUnderlyingErrorKey] = error;
        error = [NSError errorWithDomain:@"YOUR_ERROR_DOMAIN" code:9999 userInfo:dict];
        // Replace this with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}


- (NSManagedObjectContext *)managedObjectContext {
    // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.)
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (!coordinator) {
        return nil;
    }
    _managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    return _managedObjectContext;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        NSError *error = nil;
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}

@end
